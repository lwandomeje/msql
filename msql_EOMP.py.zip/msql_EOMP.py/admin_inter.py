import pymysql.cursors
from tkinter import *
from  tkinter import messagebox
import random
import tkinter as tk

show = Tk ()
show.title("LOGIN PAGE")
show.geometry("800x500")

mydb = pymysql.connect(user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline')

mycursor = mydb.cursor()

def verify():
    user_verify = adminname.get()
    pass_verify = Password.get()
    sql = "select * from admin where adminname = %s and adminPassword = %s"
    mycursor.execute(sql,[user_verify, pass_verify])
    results = mycursor.fetchall()
    if results:
        for x in results:
            logged()
            show.withdraw()
            import admin
            admin.mainloop()

    else:
        failed()

def logged():
    messagebox.showinfo("Login Page","You have successfully logged")
    adminname.delete(0, END)
    Password.delete(0, END)


def failed():
    messagebox.showinfo("Login","You failed")
    adminname.delete(0, END)
    Password.delete(0, END)

def exit_window():
    message_box = messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application')
    if message_box == 'yes':
        show.destroy()
    else:
        pass



heading = Label(show, text=' ADMIN LOGIN',font='times 30 bold underline',fg='black',bg='#D9D5D9')
heading.place(x=150,y=20)

user_lbl = Label(show,text="Enter Username")
user_lbl.place(x=50,y=100)

adminname = Entry(show)
adminname.place(x=200,y=100)



passwd_lbl = Label(show,text="Enter Password")
passwd_lbl.place(x=50,y=160)

Password = Entry(show,show= "*")
Password.place(x=200,y=160)


login_button = Button(show,text="Login",bg="skyblue",command=verify)
login_button.place(x=430,y=120)

exit_button = Button(show,text="Exit",bg="skyblue",command=exit_window)
exit_button.place(x=590,y=120)



show.mainloop()
