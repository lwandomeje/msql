import pymysql.cursors
from tkinter import *
from tkinter import messagebox
import random
import tkinter as tk

root = Tk ()
root.title("LOGIN PAGE")
root.geometry("800x500")

mydb = pymysql.connect(user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline')
mycursor = mydb.cursor()



def insert():
    id = ID_no.get()
    name = Username.get()
    type = position.get()
    cell = Cell_no.get()

    sql = "insert into life(id, userName, position, cellNo) values(%s, %s, %s, %s)"
    val = (id, name, type, cell)

    mycursor.execute(sql, val)
    mydb.commit()
    messagebox.showinfo("ADMIN","Successfully INSERTED")
    Username.delete(0, END)
    position.delete(0, END)
    Cell_no.delete(0, END)
    ID_no.delete(0, END)


#DELETE Function
def delete():
    num = int(ID_no.get())
    sql_Delete_query = "DELETE FROM life WHERE id=%s"
    mycursor.execute(sql_Delete_query, [num])
    messagebox.showinfo("ADMIN"," delete succesfully")
    ID_no.delete(0, END)

mydb.commit()


def get_all():
    mycursor.execute("Select * from life")
    for i in mycursor:
        diplay_names.insert(END, i)

def exit_window():
    message_box = messagebox.askquestion('Exit ADMIN', 'Are you sure you want to exit the application')
    if message_box == 'yes':
        root.withdraw()
        import test
        test.mainloop()

    else:
        pass

def clear_all():
    Username.delete(0, END)
    ID_no.delete(0, END)
    position.delete(0, END)
    Cell_no.delete(0, END)
    diplay_names.delete(0, END)

def add():
        root.withdraw()
        import alter_user
        alter_user.mainloop()


diplay_names = Listbox(root, bg="skyblue", fg="black", width=80, selectbackground="orange", selectforeground="black")
diplay_names.pack(pady=20)

id_lbl = Label(root,text="Enter I.D")
id_lbl.place(x=20,y=250)

ID_no = Entry(root)
ID_no.place(x=170,y=250)


user_lbl = Label(root,text="Enter Username")
user_lbl.place(x=20,y=300)

Username = Entry(root)
Username.place(x=170,y=300)

position_lbl = Label(root,text="Enter position")
position_lbl.place(x=20,y=350)

position = Entry(root)
position.place(x=170,y=350)

Cell_lbl = Label(root,text="Enter Cell_no")
Cell_lbl.place(x=20,y=400)

Cell_no = Entry(root)
Cell_no.place(x=170,y=400)

insert_button = Button(root,text="INSERT",bg="skyblue",command=insert)
insert_button.place(x=80,y=450)

get_button = Button(root,text="GET",bg="skyblue",command=get_all)
get_button.place(x=170,y=450)

delete_button = Button(root,text="DELETE",bg="skyblue",command=delete)
delete_button.place(x=240,y=450)


clear_button = Button(root,text="Clear",bg="skyblue",command=clear_all)
clear_button.place(x=10,y=450)

exit_button = Button(root,text="QUIT",bg="skyblue",command=exit_window)
exit_button.place(x=330,y=450)

exit_button = Button(root,text="addUser",bg="skyblue",command=add)
exit_button.place(x=430,y=450)

root.mainloop()
