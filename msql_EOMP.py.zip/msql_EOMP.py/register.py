import pymysql.cursors
from tkinter import *
from  tkinter import messagebox
import random
import tkinter as tk


ld = Tk ()
ld.title("LOGIN PAGE")
ld.geometry("800x500")

mydb = pymysql.connect(user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline')
mycursor = mydb.cursor()

heading = Label(ld, text='register visitor',font='times 30 bold underline',fg='black',bg='#D9D5D9')
heading.place(x=200,y=20)


def insert():
    name = Username.get()
    cell = Cell_no.get()
    sql = "insert into visitor( name, cell) values( %s, %s)"
    val = ( name,cell)
    mycursor.execute(sql, val)
    mydb.commit()
    messagebox.showinfo("ADMIN","Successfully")
    Username.delete(0, END)
    Cell_no.delete(0, END)

def quit():
    ld.withdraw()
    import user
    user.mainloop()


user_lbl = Label(ld,text="Enter Username")
user_lbl.place(x=20,y=200)

Username = Entry(ld)
Username.place(x=170,y=200)

Cell_lbl = Label(ld,text="Enter Cell_no")
Cell_lbl.place(x=20,y=250)

Cell_no = Entry(ld)
Cell_no.place(x=170,y=250)

clear_button = Button(ld,text="REGISTER",bg="skyblue",command=insert)
clear_button.place(x=10,y=300)

clear_button = Button(ld,text="QUit",bg="skyblue",command=quit)
clear_button.place(x=220,y=300)

ld.mainloop()
