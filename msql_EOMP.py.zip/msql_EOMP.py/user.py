'''from tkinter import *
from tkinter import Button,Listbox,filedialog,ttk

import tkinter as tk


show = tk.Tk()
show.title("lifechoices online")
show.geometry("800x690")
show.configure(background="lightGray")


lit_box =Listbox(show,bg='skyblue',font= "helvetice 12",width=50)
lit_box.place(x=20,y=22)

lblweight= Label(show, text= "Enter weight:", bg="skyblue")
lblweight.place(x=20 , y=260)
txtweight= Entry(show , width= 30)
txtweight.place(x=120, y=260)


btn=Button(show,text="update",bg="green", width=10)
btn.place(x=20,y=600)

btn=Button(show,text="update",bg="green", width=10)
btn.place(x=140,y=600)

btn=Button(show,text="update",bg="green", width=10)
btn.place(x=260,y=600)

btn=Button(show,text="update",bg="green", width=10)
btn.place(x=380,y=600)

show.mainloop()


import pymysql.cursors
import tkinter  as tk
from tkinter import *
my_connect = pymysql.connect(
user='lifechoices', passwd='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline'
)
my_cursor = my_connect.cursor()
####### end of connection ####

my_w = tk.Tk()
my_w.geometry("1000x200")

# add one Label
l1 = tk.Label(my_w,  text='Enter Student ID: ', width=25 )
l1.grid(row=1,column=1)

# add one text box
t1 = tk.Text(my_w,  height=1, width=4,bg='yellow')
t1.grid(row=1,column=2)

b1 = tk.Button(my_w, text='Show Details', width=15,bg='red',
    command=lambda: my_details(t1.get('1.0',END)))
b1.grid(row=1,column=4)

my_str = tk.StringVar()
# add one Label
l2 = tk.Label(my_w,  textvariable=my_str, width=100,fg='red' )
l2.grid(row=3,column=1,columnspan=2)

my_str.set("Output")

def my_details(id):
    try:
        val = int(id) # check input is integer or not
        try:
            my_cursor.execute("SELECT * FROM life ")
            student = my_cursor.fetchall()
            #print(student)
            my_str.set(student)

        except :
             my_str.set("Database error")
    except:
        my_str.set("Check input")

my_w.mainloop()

import pymysql.cursors
import tkinter  as tk
from tkinter import *
my_connect = pymysql.connect(
user='lifechoices', passwd='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline'
)


mycursor = my_connect.cursor()

sql = "INSERT INTO life VALUES (%s)"
val = ("2021-01-22")
mycursor.execute(sql, val)

my_connect.commit()

print(mycursor.rowcount, "record inserted.")'''

import pymysql.cursors
import tkinter  as tk
from tkinter import *
from  tkinter import messagebox


root = Tk ()
root.title("LOGIN PAGE")
root.geometry("510x500")

my_connect = pymysql.connect(
user='lifechoices', passwd='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline'
)
mycursor = my_connect.cursor()

def sign_in():
    time_in= ID.get()
    sql = "UPDATE life set time_IN=curtime() where id=%s"
    mycursor.execute(sql,(time_in,))
    messagebox.showinfo("LogIN","You have successfully updated recod")

    my_connect.commit()

def reg():
    root.withdraw()
    import register
    register.mainloop()




def signOut():
    time_out= ID.get()
    sql = "UPDATE life set time_OUT=curtime() where id=%s"
    mycursor.execute(sql,(time_out,))
    messagebox.showinfo("LogOUT","You have successfully updated recod")

    my_connect.commit()


def exit_window():
    message_box = messagebox.askquestion('Exit ADMIN', 'Are you sure you want to exit the application')
    if message_box == 'yes':
        root.withdraw()
        import test
        test.mainloop()

    else:
        pass



heading = Label(root, text='LOGIN',font='times 30 bold underline',fg='skyblue',bg='#D9D5D9')
heading.place(x=150,y=20)

id_lbl = Label(root,text="Enter ID")
id_lbl.place(x=10,y=160)

ID = Entry(root)
ID.place(x=100,y=160)

login_button = Button(root,text="Login",bg="green",command=sign_in)
login_button.place(x=10,y=220)

logout_button = Button(root,text="logout",bg="green",command=signOut)
logout_button.place(x=100,y=220)

logout_button = Button(root,text="REGISTER",bg="green",command=reg)
logout_button.place(x=190,y=220)

exit_button = Button(root,text="QUIT",bg="skyblue",command=exit_window)
exit_button.place(x=390,y=220)







root.mainloop()
