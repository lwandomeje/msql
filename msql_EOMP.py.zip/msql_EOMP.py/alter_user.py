import pymysql.cursors
from tkinter import *
from tkinter import messagebox
import random
import tkinter as tk

root = Tk ()
root.title("LOGIN PAGE")
root.geometry("500x500")

mydb = pymysql.connect(user='lifechoices', password='@Lifechoices1234', host='127.0.0.1', database='lifechoicesonline')
mycursor = mydb.cursor()

heading = Label(root, text='ADD USER',font='times 30 bold underline',fg='skyblue',bg='#D9D5D9')
heading.place(x=150,y=100)



def insert():
    id = ID_no.get()
    name = Username.get()
    type = position.get()
    sql = "insert into users(id, username, password) values(%s, %s, %s)"
    val = (id, name, type,)

    mycursor.execute(sql, val)
    mydb.commit()
    messagebox.showinfo("ADMIN","Successfully INSERTED")
    Username.delete(0, END)
    position.delete(0, END)
    ID_no.delete(0, END)

def delete():
    num = int(ID_no.get())
    sql_Delete_query = "DELETE FROM users WHERE id=%s"
    mycursor.execute(sql_Delete_query, [num])
    messagebox.showinfo("ADMIN"," delete succesfully")
    ID_no.delete(0, END)

mydb.commit()



id_lbl = Label(root,text="Enter I.D")
id_lbl.place(x=20,y=250)

ID_no = Entry(root)
ID_no.place(x=170,y=250)


user_lbl = Label(root,text="Enter Username")
user_lbl.place(x=20,y=300)

Username = Entry(root)
Username.place(x=170,y=300)

position_lbl = Label(root,text="Enter password")
position_lbl.place(x=20,y=350)

position = Entry(root)
position.place(x=170,y=350)


insert_button = Button(root,text="INSERT",bg="skyblue",command=insert)
insert_button.place(x=80,y=450)
delete_button = Button(root,text="DELETE",bg="skyblue",command=delete)
delete_button.place(x=240,y=450)



root.mainloop()
